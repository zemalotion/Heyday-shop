const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function loadEnv() {
  try {
    const raw = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    for (const line of raw.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
      if (m && !m[1].startsWith('#') && process.env[m[1]] === undefined) {
        process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
      }
    }
  } catch {}
}
loadEnv();

const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const LINE_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || '';
const LINE_CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET || '';
const LINE_TO = process.env.LINE_ADMIN_TO || '';
const PUBLIC_SITE_URL = process.env.PUBLIC_SITE_URL || '';
const PUBLIC_DIR = path.join(__dirname, 'public');

const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'products.json'), 'utf8'));
const categories = [
  {id:'all',label:'🌿 ทั้งหมด'}, {id:'basic',label:'🥛 ของพื้นฐาน'},
  {id:'animal',label:'🐮 สัตว์/ผลิตภัณฑ์'}, {id:'crop',label:'🌽 ผลผลิต'},
  {id:'special',label:'💎 ไอเทมพิเศษ'}
];

function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type':type,'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function jsonBody(req) {
  return new Promise((resolve,reject)=>{
    let body='', size=0;
    req.on('data',chunk=>{size+=chunk.length;if(size>100000){reject(new Error('ข้อมูลมีขนาดใหญ่เกินไป'));req.destroy();return;}body+=chunk;});
    req.on('end',()=>{try{resolve(body?JSON.parse(body):{});}catch{reject(new Error('รูปแบบข้อมูลไม่ถูกต้อง'));}});
    req.on('error',reject);
  });
}
function configured(){return !!(SUPABASE_URL && SUPABASE_KEY);}
function adminOK(req){return !!ADMIN_PASSWORD && safeEqual(req.headers['x-admin-password'] || '', ADMIN_PASSWORD);}
function safeEqual(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length && crypto.timingSafeEqual(x,y);}
async function db(pathname, options={}) {
  if(!configured()) throw new Error('ยังไม่ได้ตั้งค่า Supabase');
  const r=await fetch(`${SUPABASE_URL}/rest/v1/${pathname}`,{
    method:options.method||'GET',
    headers:{'apikey':SUPABASE_KEY,'Authorization':`Bearer ${SUPABASE_KEY}`,'Content-Type':'application/json','Prefer':options.prefer||'return=representation',...(options.headers||{})},
    body:options.body===undefined?undefined:JSON.stringify(options.body)
  });
  const text=await r.text(); let data=null;try{data=text?JSON.parse(text):null}catch{data=text}
  if(!r.ok) { const e=new Error(typeof data==='object'?(data.message||data.hint||'ฐานข้อมูลตอบกลับผิดพลาด'):'ฐานข้อมูลตอบกลับผิดพลาด');e.status=r.status;throw e; }
  return data;
}
async function lineNotifyOrder(order) {
  if(!LINE_TOKEN || !LINE_TO) return {sent:false,reason:'ยังไม่ได้ตั้งค่า LINE'};
  const detail=order.items.map(i=>`${i.emoji} ${i.name} x${i.qty} = ${i.price*i.qty} เหรียญ`).join('\n');
  const message=`🛒 มีออเดอร์ใหม่!\nเลขออเดอร์: ${order.order_code}\nลูกค้า: ${order.customer_name}\nชื่อฟาร์ม/ผู้เล่น: ${order.player_name}\nแท็กผู้เล่น: ${order.player_tag||'-'}\nช่องทางติดต่อ: ${order.contact||'-'}\n\n${detail}\n\nยอดรวม: ${order.total} เหรียญ\nหมายเหตุ: ${order.note||'-'}\nสถานะ: ${order.status}${PUBLIC_SITE_URL?`\n\nหลังบ้าน: ${PUBLIC_SITE_URL}/admin`:''}`;
  const r=await fetch('https://api.line.me/v2/bot/message/push',{
    method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${LINE_TOKEN}`},
    body:JSON.stringify({to:LINE_TO,messages:[{type:'text',text:message.slice(0,4900)}]})
  });
  if(!r.ok){const t=await r.text();console.error('LINE push failed:',r.status,t);return {sent:false,reason:'LINE API ส่งไม่สำเร็จ'};}
  return {sent:true};
}
function makeCode(){const d=new Date();const stamp=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('');return `HD${stamp}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;}
function staticFile(req,res){
  let pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
  if(pathname==='/')pathname='/index.html';
  if(pathname==='/admin')pathname='/admin.html';
  const target=path.normalize(path.join(PUBLIC_DIR,pathname));
  if(!target.startsWith(PUBLIC_DIR))return send(res,403,{error:'ไม่อนุญาต'});
  fs.readFile(target,(err,data)=>{
    if(err)return send(res,404,{error:'ไม่พบหน้าเว็บ'},'text/plain; charset=utf-8');
    const ext=path.extname(target);
    const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml'};
    send(res,200,data,types[ext]||'application/octet-stream');
  });
}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://localhost');
  try{
    if(req.method==='POST'&&url.pathname==='/webhook'){
      const rawChunks=[]; let rawSize=0;
      for await (const chunk of req) {
        rawSize += chunk.length;
        if (rawSize > 100000) return send(res,413,{error:'Payload too large'});
        rawChunks.push(chunk);
      }
      const raw=Buffer.concat(rawChunks);
      const signature=String(req.headers['x-line-signature']||'');
      if(!LINE_CHANNEL_SECRET) return send(res,503,{error:'ยังไม่ได้ตั้งค่า LINE_CHANNEL_SECRET'});
      const expected=crypto.createHmac('sha256',LINE_CHANNEL_SECRET).update(raw).digest('base64');
      if(!safeEqual(signature,expected)) return send(res,401,{error:'ลายเซ็น LINE ไม่ถูกต้อง'});
      let eventBody;
      try{eventBody=JSON.parse(raw.toString('utf8'));}catch{return send(res,400,{error:'JSON ไม่ถูกต้อง'});}
      for(const event of (eventBody.events||[])){
        if(event.source && event.source.type==='group' && event.source.groupId) console.log('LINE_GROUP_ID:',event.source.groupId);
        else if(event.source && event.source.type==='room' && event.source.roomId) console.log('LINE_ROOM_ID:',event.source.roomId);
      }
      return send(res,200,{ok:true});
    }
    if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,databaseConfigured:configured(),lineConfigured:!!(LINE_TOKEN&&LINE_TO),lineWebhookConfigured:!!LINE_CHANNEL_SECRET});
    if(req.method==='GET'&&url.pathname==='/api/products')return send(res,200,{products,categories});
    if(req.method==='POST'&&url.pathname==='/api/orders'){
      const body=await jsonBody(req);
      const customer_name=String(body.customer_name||'').trim().slice(0,80);
      const player_name=String(body.player_name||'').trim().slice(0,80);
      const player_tag=String(body.player_tag||'').trim().slice(0,80);
      const contact=String(body.contact||'').trim().slice(0,120);
      const note=String(body.note||'').trim().slice(0,500);
      if(!customer_name||!player_name)return send(res,400,{error:'กรุณากรอกชื่อผู้สั่งและชื่อฟาร์ม/ผู้เล่น'});
      if(!Array.isArray(body.items)||body.items.length<1||body.items.length>30)return send(res,400,{error:'กรุณาเลือกสินค้า 1–30 รายการ'});
      const clean=[];
      for(const row of body.items){
        const p=products.find(p=>p.id===row.id),qty=Number(row.qty);
        if(!p||!Number.isInteger(qty)||qty<1||qty>999)return send(res,400,{error:'รายการสินค้าหรือจำนวนไม่ถูกต้อง'});
        clean.push({id:p.id,name:p.name,emoji:p.emoji,price:p.price,qty});
      }
      const total=clean.reduce((sum,i)=>sum+i.price*i.qty,0);
      if(!configured())return send(res,503,{error:'เว็บไซต์ยังไม่ได้เชื่อมฐานข้อมูล กรุณาติดต่อผู้ดูแลระบบ'});
      const order={order_code:makeCode(),customer_name,player_name,player_tag,contact,note,items:clean,total,status:'รอรับออเดอร์'};
      let inserted;
      try{inserted=await db('orders',{method:'POST',body:order,prefer:'return=representation'})}
      catch(e){if(e.status===409){order.order_code=makeCode();inserted=await db('orders',{method:'POST',body:order})}else throw e;}
      const saved=Array.isArray(inserted)?inserted[0]:inserted;
      const line=await lineNotifyOrder(saved||order);
      return send(res,201,{order:saved||order,lineSent:line.sent,lineMessage:line.sent?'แจ้ง LINE แล้ว':'บันทึกออเดอร์แล้ว แต่แจ้ง LINE ไม่สำเร็จ/ยังไม่ตั้งค่า'});
    }
    if(url.pathname.startsWith('/api/admin/')){
      if(!adminOK(req))return send(res,401,{error:'รหัสผ่านแอดมินไม่ถูกต้อง'});
      if(req.method==='GET'&&url.pathname==='/api/admin/orders'){
        const status=url.searchParams.get('status');
        const query=status?`orders?select=*&status=eq.${encodeURIComponent(status)}&order=created_at.desc&limit=300`:'orders?select=*&order=created_at.desc&limit=300';
        return send(res,200,await db(query));
      }
      const match=url.pathname.match(/^\/api\/admin\/orders\/([0-9a-f-]+)$/i);
      if(req.method==='PATCH'&&match){
        const body=await jsonBody(req);
        const allowed=['รอรับออเดอร์','กำลังจัดของ','กำลังส่ง','ส่งสำเร็จ','ยกเลิก'];
        if(!allowed.includes(body.status))return send(res,400,{error:'สถานะไม่ถูกต้อง'});
        const result=await db(`orders?id=eq.${encodeURIComponent(match[1])}`,{method:'PATCH',body:{status:body.status,updated_at:new Date().toISOString()}});
        if(!result||!result.length)return send(res,404,{error:'ไม่พบออเดอร์'});
        return send(res,200,result[0]);
      }
      return send(res,404,{error:'ไม่พบ API'});
    }
    if(req.method==='GET')return staticFile(req,res);
    return send(res,405,{error:'Method not allowed'});
  }catch(e){console.error(e);return send(res,e.status&&e.status<500?e.status:500,{error:e.message||'เกิดข้อผิดพลาด'});}
});
server.listen(PORT,()=>console.log(`Hay Day Shop running on port ${PORT}`));
