# Hay Day Shop Online

เว็บรับออเดอร์ตัวอย่างภาษาไทย พร้อมหน้าร้าน, ตะกร้า, สร้างเลขออเดอร์, ฐานข้อมูล Supabase, หน้าแอดมิน และแจ้งออเดอร์ผ่าน LINE Messaging API

> เว็บนี้ไม่ใช่บริการอย่างเป็นทางการของ Supercell/Hay Day ราคาสินค้าเป็นข้อมูลตัวอย่าง ต้องแก้เป็นราคาจริงก่อนเปิดร้าน

## สิ่งที่ต้องมี

- บัญชี GitHub สำหรับเก็บ source code
- บัญชี Supabase สำหรับฐานข้อมูล
- บัญชี LINE Official Account และ LINE Developers สำหรับส่งข้อความอัตโนมัติ
- บริการโฮสต์ Node.js เช่น Render

## 1) ตั้งค่าฐานข้อมูล Supabase

1. สร้างโปรเจกต์ที่ https://supabase.com/
2. เปิด **SQL Editor** แล้วรันเนื้อหาใน `schema.sql`
3. ไปที่ **Project Settings → API** คัดลอก Project URL และ `service_role` key
4. ห้ามนำ `service_role` key ไปใส่ในไฟล์หน้าเว็บหรือส่งให้ลูกค้า

## 2) ตั้งค่า LINE Messaging API

1. สร้าง/ใช้ LINE Official Account และเปิด Messaging API ผ่าน LINE Official Account Manager
2. ใน LINE Developers สร้าง Provider/Channel แบบ Messaging API
3. ออก Channel access token
4. ตั้งค่า `LINE_ADMIN_TO` เป็น LINE user ID, group ID หรือ room ID ที่บอทได้รับอนุญาตให้ส่งข้อความได้
5. ถ้าจะส่งเข้าแชทกลุ่ม ให้เพิ่ม Official Account เข้ากลุ่มและตั้งค่าการอนุญาตเข้ากลุ่มตามข้อกำหนดของ LINE
6. ทดสอบให้บอทส่งข้อความได้ก่อนเปิดร้านจริง

การส่งข้อความใช้ LINE Messaging API Push Message ไม่ใช่ LINE Notify โดยปลายทางต้องเป็นผู้ใช้/กลุ่มที่บอทสามารถส่งข้อความหาได้

## แก้ไขสินค้าและราคาของร้าน

แก้ไฟล์ `products.json` ในโฟลเดอร์หลัก โดยแต่ละรายการมี `id`, `name`, `emoji`, `price`, `cat`, `desc`:
- `price` คือราคาต่อชิ้น ให้ใส่เป็นตัวเลข เช่น `35`
- `id` ต้องไม่ซ้ำกัน
- `cat` ใช้ `basic`, `animal`, `crop` หรือ `special`
- อย่าลบเครื่องหมายจุลภาค/วงเล็บของ JSON และตรวจให้ไฟล์เป็น JSON ที่ถูกต้อง
- หลังแก้ไฟล์ ให้อัปโหลด commit ขึ้น GitHub แล้ว deploy ใหม่

**หมายเหตุ:** ราคายังแก้จากไฟล์และต้อง deploy ใหม่ ไม่ใช่หน้าแก้ราคาจากแอดมิน

## 3) ตั้งค่า environment variables

คัดลอก `.env.example` เป็น `.env` แล้วใส่ค่าจริง หรือกำหนดค่าผ่าน Environment Variables ในผู้ให้บริการโฮสต์:

- `ADMIN_PASSWORD`: ตั้งรหัสผ่านแอดมินที่ยาวและไม่ซ้ำที่อื่น
- `SUPABASE_URL`: Project URL
- `SUPABASE_SERVICE_ROLE_KEY`: service role key จาก Supabase (เก็บเป็น secret)
- `LINE_CHANNEL_ACCESS_TOKEN`: token ของ LINE Messaging API
- `LINE_ADMIN_TO`: user ID / group ID / room ID ปลายทาง
- `PUBLIC_SITE_URL`: URL เว็บที่ deploy แล้ว (ไม่จำเป็น แต่ใช้ใส่ในข้อความแจ้งเตือน)
- `PORT`: ผู้ให้บริการโฮสต์ส่วนใหญ่กำหนดให้อัตโนมัติ

**อย่า commit `.env` หรือเปิดเผย secret ใน GitHub**

## 4) ทดสอบในเครื่อง

ต้องติดตั้ง Node.js 20 ขึ้นไป

```bash
cp .env.example .env
# แก้ .env ด้วยค่าจริง
npm start
```

จากนั้นเปิด `http://localhost:3000` สำหรับหน้าร้าน และ `http://localhost:3000/admin` สำหรับหน้าแอดมิน

ถ้าไม่ตั้งค่า Supabase จะยังดูหน้าเว็บได้ แต่การส่งออเดอร์จริงจะถูกปฏิเสธ ไม่ได้บันทึกลงฐานข้อมูล

## 5) เผยแพร่ออนไลน์ด้วย Render

1. อัปโหลดไฟล์โปรเจกต์นี้ขึ้น GitHub repository ส่วนตัว
2. เข้า https://render.com/ แล้วสร้าง **New → Web Service** เลือก repository
3. Runtime: Node; Build command: `npm install` (ไม่มี dependency ภายนอก); Start command: `npm start`
4. ตั้ง Environment Variables ตามหัวข้อ 3 ในหน้า Render
5. Deploy และเปิด URL ที่ Render ให้
6. ตั้ง `PUBLIC_SITE_URL` เป็น URL จริง แล้ว redeploy
7. ทดสอบสั่งซื้อ 1 รายการ และตรวจสอบทั้ง Supabase กับ LINE ของร้าน
8. เข้า `/admin` แล้วล็อกอินด้วย `ADMIN_PASSWORD`

## หมายเหตุด้านความปลอดภัยและการใช้งานจริง

- รหัสแอดมินส่งจากเบราว์เซอร์ไปตรวจสอบที่เซิร์ฟเวอร์ทุกครั้ง ใช้ HTTPS ของผู้ให้บริการโฮสต์ และอย่าใช้รหัสผ่านเดียวกับบัญชีอื่น
- หน้าแอดมินไม่ควรถูกแชร์สาธารณะ; มี `noindex` ช่วยลดการแสดงผลในเสิร์ช แต่ไม่ใช่ระบบป้องกันการเข้าถึง
- สำหรับร้านที่มีปริมาณออเดอร์สูง ควรเพิ่ม rate limiting, audit log, ระบบล็อกอินแอดมินที่มี session หมดอายุ, CAPTCHA/anti-spam และระบบแจ้งเตือนเมื่อ LINE ส่งไม่สำเร็จ
- ตอนนี้สินค้าและราคาถูกกำหนดใน `server.js` ให้แก้ในไฟล์นี้แล้ว deploy ใหม่เมื่อปรับราคา
- สถานะและออเดอร์เก็บใน Supabase จึงไม่หายเมื่อผู้ใช้เปลี่ยนอุปกรณ์
- ระบบนี้ไม่ได้ทำธุรกรรมชำระเงินอัตโนมัติ และการแจ้ง LINE จะทำงานก็ต่อเมื่อตั้งค่า credentials/recipient ถูกต้อง
