# ตั้งค่า LINE กลุ่มแอดมิน (ภาษาไทย)

1. สร้าง/เลือก LINE Official Account ของร้าน แล้วเปิด Messaging API ผ่าน LINE Official Account Manager
2. เปิด LINE Developers Console แล้วเลือก Messaging API channel ของร้าน
3. ที่แท็บ Messaging API คัดลอก Channel access token และ Channel secret เก็บไว้เป็นความลับ
4. ตั้งค่าบนบริการโฮสต์: `LINE_CHANNEL_ACCESS_TOKEN`, `LINE_CHANNEL_SECRET`; เว้น `LINE_ADMIN_TO` ไว้ก่อนจนกว่าจะได้ Group ID
5. ใน LINE Developers เปิด **Allow bot to join group chats** และเปิดการใช้ Webhook
6. Deploy เว็บไซต์ก่อน แล้วตั้ง Webhook URL เป็น `https://โดเมนเว็บไซต์จริง/webhook` จากนั้นกด Verify
7. เชิญ LINE Official Account เข้ากลุ่ม LINE แอดมินของร้าน
8. ส่งข้อความใดก็ได้ในกลุ่ม เพื่อให้ LINE ส่ง webhook event มายังเว็บ
9. เปิด Logs ของเว็บโฮสต์ แล้วค้นหา `LINE_GROUP_ID:` คัดลอก group ID ที่แสดง
10. กลับไปตั้ง `LINE_ADMIN_TO` ให้เป็น group ID นั้น แล้ว redeploy
11. ทดสอบสั่งซื้อจากหน้าเว็บ แล้วตรวจสอบว่าข้อความออเดอร์เข้าในกลุ่ม

## หากยังไม่แจ้งเตือน

- ตรวจว่า LINE Official Account ยังอยู่ในกลุ่ม
- ตรวจว่า Webhook URL ใช้ HTTPS และลงท้ายด้วย `/webhook`
- ตรวจว่า `LINE_CHANNEL_SECRET` และ `LINE_CHANNEL_ACCESS_TOKEN` มาจาก channel เดียวกัน
- ตรวจว่า `LINE_ADMIN_TO` เป็น group ID ไม่ใช่ชื่อกลุ่ม
- ดู log ของเว็บโฮสต์ว่ามีข้อผิดพลาดจาก LINE API หรือไม่

## ความปลอดภัย

อย่าส่ง token, channel secret, Supabase service-role key หรือรหัสผ่านแอดมินในแชตหรือ commit ขึ้น GitHub อย่าใส่ค่า secret ในไฟล์ `public/` เด็ดขาด
