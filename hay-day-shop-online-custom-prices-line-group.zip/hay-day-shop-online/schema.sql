-- Run this in Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text unique not null,
  customer_name text not null,
  player_name text not null,
  player_tag text default '',
  contact text default '',
  note text default '',
  items jsonb not null,
  total integer not null check (total >= 0),
  status text not null default 'รอรับออเดอร์'
    check (status in ('รอรับออเดอร์','กำลังจัดของ','กำลังส่ง','ส่งสำเร็จ','ยกเลิก')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists orders_created_at_idx on public.orders (created_at desc);
create index if not exists orders_status_idx on public.orders (status);

-- Keep RLS enabled and do not add public read/write policies.
-- The Node server uses the service-role key on the server only.
alter table public.orders enable row level security;
